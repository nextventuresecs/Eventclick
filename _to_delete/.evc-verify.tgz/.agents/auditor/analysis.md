# Adversarial Review / Critic Challenge Report

## Challenge Summary

**Overall risk assessment**: LOW

## Challenges

### [Medium] Challenge 1: Reliance on daily cron/sweeper for Production QA isolation

- **Assumption challenged**: Ephemeral database cleaning via daily cron/sweeper ensures complete donor report isolation.
- **Attack scenario**: If the BullMQ or AWS ECS Task Cron fails silently, test data associated with organization `ffffffff-ffff-ffff-ffff-ffffffffffff` will persist. This could lead to dirty analytics or bleed into aggregate donor reporting.
- **Blast radius**: Performance degradation and compliance reporting pollution.
- **Mitigation**: 
  - Enforce Postgres Row-Level Security (RLS) where default queries exclude the QA tenant UUID unless explicitly run under a `QA_REPORTING` role.
  - Implement active alerts (e.g., via PagerDuty/Sentry) if the daily sweeper daemon does not run or returns an error.

### [Medium] Challenge 2: Fragile WebRTC assertions in Playwright

- **Assumption challenged**: Checking video visibility and `readyState === 4` guarantees WebRTC stream function.
- **Attack scenario**: A video tag can have `readyState === 4` but be rendering static black frames or have audio packet drops.
- **Blast radius**: Undetected stream drops or encoding failures in live field monitoring.
- **Mitigation**: Assert active stream data transmission by fetching RTC stats from the browser context or verifying that video frame timestamps increment over time.

### [Low] Challenge 3: HMAC-based rate-limit bypass token security

- **Assumption challenged**: Custom middleware HMAC verification is secure from abuse.
- **Attack scenario**: Replay attacks or compromised HMAC secrets.
- **Blast radius**: Dastardly DDoS attacks that exhaust the Redis rate-limiter backend.
- **Mitigation**: Embed a short-lived unix timestamp within the HMAC signature so that token headers expire after a few minutes, preventing replay attacks.

## Stress Test Results

- **Daily cleanup failure scenario** → Sweeper crashes → Test data persists → **FAIL** (Pollutes dashboard aggregates)
- **Playwright video readyState check** → Frozen video track → Playwright passes → **FAIL** (Undetected streaming failures)
- **Static HMAC Header** → Header token leaked → Rate-limiting bypassed → **FAIL** (Denial of Service risk)

## Unchallenged Areas

- **CI/CD pipeline structure** — Out-of-the-box GitHub Action patterns are standard and require no extra stress-testing.
- **Responsibility matrix** — Project organizational mapping is static and correct.
