## 2026-07-16T13:59:31Z

You are Explorer 2 (Performance & Security).
Objective: Recommend the Performance and Security testing strategy for Eventclick.
Tasks:
1. Read ORIGINAL_REQUEST.md at the project root and .agents/orchestrator/plan.md.
2. Read docs/cloudflare-setup.md to understand the current AWS + Cloudflare infrastructure.
3. Propose a performance testing strategy (e.g. using k6) that handles staging and production.
4. Propose a security testing strategy suggesting specific tools (e.g., OWASP ZAP, Burp Suite, dependency scanners) and where they fit in the life cycle.
5. Save your findings in a markdown file at `.agents/explorer_2/analysis.md`. Update progress.md in your folder regularly (e.g., `.agents/explorer_2/progress.md`).
6. Deliver a handoff.md in your folder and report completion.
