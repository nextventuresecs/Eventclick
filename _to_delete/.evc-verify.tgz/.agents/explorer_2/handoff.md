# Handoff Report — Explorer 2 (Performance & Security)

## 1. Observation
We examined the current layout of the codebase, the Cloudflare guide, and the Express app configuration:
- In `docs/cloudflare-setup.md` (lines 143-145), the production and staging configuration blocks bot traffic to the API:
  ```
  Expression: (http.request.uri.path contains "/api/" and cf.client.bot)
  Action: Block
  ```
- In `packages/server/src/index.ts` (lines 79-85), the server configures rate-limiting using `rate-limit-redis`:
  ```typescript
  app.use(
    rateLimit({
      windowMs: env.RATE_LIMIT_WINDOW_MS,
      limit: env.RATE_LIMIT_MAX,
      standardHeaders: "draft-7",
      legacyHeaders: false,
      store: new RedisStore({
  ```
- In `packages/server/src/config/env.ts` (lines 24-25), the default rate limit values are parsed:
  ```typescript
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(100),
  ```
- No E2E or performance/security testing workflows are currently present in the client or server CI pipelines.

---

## 2. Logic Chain
- **Performance Bypass Logic**:
  - Because Cloudflare is configured to block suspicious bot traffic to the `/api/` path, any standard automated performance test runner (like k6) will be blocked at the edge. 
  - To resolve this, the k6 runner must either target the origin IP directly (Direct-to-Origin routing) or pass a custom validation header (`X-Eventclick-Loadtest-Key`) matched by a Cloudflare WAF skip rule.
- **Express Rate-Limit Bypass Logic**:
  - Because the server rate-limiter is configured to enforce `RATE_LIMIT_MAX` (default 100 requests per minute) per client IP using Redis, standard load tests will immediately trigger HTTP 429 Errors.
  - To resolve this, the Express server should implement custom skip logic (e.g. verifying `X-Bypass-Rate-Limit` header) or increase `RATE_LIMIT_MAX` on Staging during test execution windows.
- **Security Strategy Selection**:
  - Since the application processes sensitive user identities, attendance tracking, and organization borders, we require a multi-layered DevSecOps approach:
    - **Local**: Secrets Scanning (GitLeaks) and IDE SAST (ESLint Security).
    - **Build**: Automated SAST (Semgrep) and SCA (npm audit / Snyk).
    - **Post-Deploy Staging**: Automated dynamic scanning (OWASP ZAP).
    - **Manual**: IDOR logical isolation audits targeting tenant boundaries using Burp Suite Pro.

---

## 3. Caveats
- **LiveKit/WebRTC load testing**: LiveKit Cloud is a third-party managed service. Standard HTTP load tests using k6 should mock LiveKit token generation and room creation endpoints to avoid running up high bandwidth consumption costs on LiveKit Cloud. Running actual WebRTC stream simulation requires LiveKit's dedicated load-testing utility (`livekit-cli`) or a custom k6 build with the `xk6-webrtc` extension.
- **Bypass implementation**: We did not make code changes to bypass the rate limiter or add WAF rules, as this is a read-only investigation role. The implementer must implement the rate-limit bypass middleware header.

---

## 4. Conclusion
The proposed testing strategy successfully establishes a template for:
1. **k6 Performance Scripts**: Testing staging and production environments using WAF and rate-limiting bypass keys, checking response thresholds (95% of API requests < 500ms, error rate < 1%), and targeting 5 key user journeys.
2. **Security Pipeline**: A multi-layered structure mapping tools (GitLeaks, ESLint Security, Semgrep, npm audit, OWASP ZAP, Burp Suite) to lifecycle stages (Dev, Commit, Build, Staging, Pre-release).
3. **CI/CD Blueprints**: Ready-to-copy GitHub Actions workflows for continuous security checking and load-test smoke gating.

The complete strategy is saved at `.agents/explorer_2/analysis.md`.

---

## 5. Verification Method
To independently verify this investigation:
1. Confirm that the strategy file `.agents/explorer_2/analysis.md` exists and contains sections on:
   - k6 performance testing (Staging/Production environments, Cloudflare WAF bypass, Express rate-limit bypass, test data management).
   - Security testing strategy (tool selection matrix, lifecycle stages integration: SAST, SCA, DAST, manual pentests, container checks).
   - CI/CD pipeline code blueprints.
2. Run the server unit and integration tests using:
   ```bash
   cd packages/server && npm run test
   ```
   to confirm the codebase tests pass and the rate-limiter and configuration logic remain unaltered.
