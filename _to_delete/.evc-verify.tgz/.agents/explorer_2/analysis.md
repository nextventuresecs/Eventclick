# Performance & Security Testing Strategy — Eventclick

This document outlines the proposed Performance and Security testing strategy for Eventclick, a multi-tenant, real-time NGO transparency and verification platform. It details the tools, methodologies, environment handling, and CI/CD integration blueprints.

---

## 1. Executive Summary

Eventclick is a high-stakes, real-time platform handling WebRTC streams (LiveKit), attendance audits, and multi-tenant organization boundaries. Ensuring robust performance under load and strong resistance to security vulnerabilities is critical. 

This strategy introduces:
1. **Performance Testing via Grafana k6**: Executed against Staging (and safely against Production) using custom Cloudflare and application rate-limit bypasses to simulate realistic user behavior without service disruption or false alerts.
2. **Security Testing Lifecycle**: A multi-layered DevSecOps approach containing Secrets Scanning, Static Application Security Testing (SAST), Software Composition Analysis (SCA), Dynamic Application Security Testing (DAST), and manual penetration testing integrated across different phases of the software development lifecycle (SDLC).
3. **Automated CI/CD Workflows**: Verification gates built into GitHub Actions to enforce performance SLAs and security compliance automatically.

---

## 2. Performance Testing Strategy

We recommend **Grafana k6** as the core performance testing tool. k6 uses developer-friendly JavaScript/TypeScript scripts, has low system resource consumption, and supports HTTP, WebSockets, and gRPC protocols.

### 2.1 Staging vs. Production Testing

| Phase | Environment | Purpose | Target Load | Safe execution mechanism |
|---|---|---|---|---|
| **Staging** | Replica of AWS (EC2 + RDS Postgres + Redis) | Validate code optimizations, DB connection pooling, and baseline responsiveness. | High (up to Stress/Soak levels) | Run against a dedicated staging deployment. Direct origin testing is allowed. |
| **Production** | Live Production environment | Validate end-to-end performance including Cloudflare edge routing and AWS resource scaling under real-world conditions. | Moderate (limited to Peak Load) | Execute only during off-peak hours (e.g., 02:00-04:00 UTC). Coordinate with the team and active monitors. |

### 2.2 Network Routing & Cloudflare Bypass Strategy

Because Eventclick uses Cloudflare for DDoS protection, CDN caching, Bot Fight Mode, and WAF rules (specifically blocking non-browser/suspicious bot API requests), run-of-the-mill load tests will be blocked at the edge. To execute load tests successfully:

#### Option A: Direct-to-Origin Routing (Preferred for Staging)
1. **Runner Location**: Run the k6 load generator inside the same AWS VPC as the EC2 staging instance, or add the runner's IP address to the EC2 security group.
2. **DNS Bypass**: Direct the k6 script to target the origin IP directly (e.g., `http://<EC2_ELASTIC_IP>:<PORT>`) rather than `api.eventclick.com`, setting the host header manually:
   ```javascript
   http.get('http://1.2.3.4/api/v1/health', {
     headers: { 'Host': 'api.eventclick.com' }
   });
   ```
   *Benefit*: Avoids Cloudflare usage charges, billing metrics pollution, and rate limiting at the edge.

#### Option B: Cloudflare WAF Bypass (Required for Production/E2E Staging)
1. **WAF Custom Bypass Rule**: Configure a custom WAF rule in Cloudflare with the action **"Skip"** (Bypassing Bot Fight Mode, Managed Rules, and WAF Rules) when a specific secret token is sent:
   * **Field**: `Header`
   * **Operator**: `equals`
   * **Value**: `x-eventclick-loadtest-key` matches `<SECRET_HMAC_TOKEN>`
2. **k6 Script Integration**: Add the custom header to all requests sent by the k6 runner.

### 2.3 Application Layer Rate-Limit Bypass

Eventclick utilizes `express-rate-limit` backed by Redis on the application server (restricting requests to `env.RATE_LIMIT_MAX` per `RATE_LIMIT_WINDOW_MS`). During load testing, these limits will trigger 429 Errors. To bypass:

1. **Environment Configuration (Staging)**: Set `RATE_LIMIT_MAX` to a very high number (e.g. `100000`) during load test windows.
2. **Secure Bypass Middleware (Staging & Production)**: Modify the rate-limiting middleware in the application to check for an authentication token or a specific validation key (e.g., `X-Bypass-Rate-Limit`) and skip incrementing the Redis counter if valid:
   ```typescript
   // Recommended pattern in server/src/index.ts or a wrapper middleware
   const bypassToken = process.env.LOAD_TEST_BYPASS_TOKEN;
   
   app.use(
     rateLimit({
       // ... rate limit configs ...
       skip: (req) => {
         return !!(bypassToken && req.headers['x-bypass-rate-limit'] === bypassToken);
       }
     })
   );
   ```

### 2.4 Test Data Management

To prevent pollution of production data and maintain staging isolation:
1. **Dedicated Test Tenant**: Run tests under a specific organization reserved for testing (e.g., `OrganizationID` set to a fixed test UUID in the DB).
2. **Prefixed Data**: Generate mock volunteers, events, and attendees with specific prefixes (e.g. `test_user_...`, `test_event_...`).
3. **Database Seed & Teardown scripts**:
   - Create a pre-test seed script that inserts required lookup data (users, organizations, event rooms) using direct Drizzle script files.
   - Create a post-test teardown script that deletes records associated with the test organization UUID:
     ```sql
     DELETE FROM attendance_entries WHERE organization_id = 'TEST_ORG_UUID';
     DELETE FROM event_rooms WHERE organization_id = 'TEST_ORG_UUID';
     DELETE FROM users WHERE email LIKE 'test_user_%@eventclick.com';
     ```
4. **Third-Party Mocks**:
   - **Emails**: Disable real email sending via Resend in the testing environment (fallback to a log/mock driver).
   - **LiveKit**: For standard HTTP/API load testing, mock the LiveKit Token generation responses or isolate WebRTC connections to prevent consuming production LiveKit Cloud capacity.

### 2.5 Critical User Journeys to Load-Test

k6 scripts should simulate these five key flows representing the core user journeys:
1. **User Authentication & Session Setup**: Heavy load on JWT token signing and Redis session store verification.
2. **Event Room Retrieval (Home & Detail Pages)**: Focuses on read-heavy DB operations, validating indexes and Drizzle schema relations.
3. **Attendee Verification Check-in**: High-write frequency (inserting into `attendance_entries` and verifying coordinates / timestamps).
4. **Live Field Upload (Photo & Recording Metadata)**: Simulates uploading a photo or recording. In testing, upload small payload sizes and target a mock S3 endpoint (or staging MinIO) to avoid Cloudflare R2 cost spikes.
5. **Real-time Event Room Interaction**: High-frequency websocket connection initialization and polling.

### 2.6 k6 Load Testing Script Example

Create a k6 test script in `packages/shared/docs/testing/load-test.js`:

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

// Define scenarios
export const options = {
  scenarios: {
    // 1. Smoke test (verify scripts work)
    smoke: {
      executor: 'constant-vus',
      vus: 2,
      duration: '30s',
      gracefulStop: '5s',
    },
    // 2. Load test (typical load)
    load: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '2m', target: 50 },  // Ramp up
        { duration: '5m', target: 50 },  // Stay at peak
        { duration: '1m', target: 0 },   // Ramp down
      ],
      gracefulRampDown: '30s',
      startTime: '35s', // Runs after smoke test completes
    }
  },
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% of requests must complete below 500ms
    http_req_failed: ['rate<0.01'],    // Error rate must be less than 1%
  },
};

const BASE_URL = __ENV.TARGET_URL || 'https://api-staging.eventclick.com/api/v1';
const BYPASS_KEY = __ENV.BYPASS_KEY || 'staging-test-token-1234';

export default function () {
  const params = {
    headers: {
      'Content-Type': 'application/json',
      'X-Eventclick-Loadtest-Key': BYPASS_KEY, // Cloudflare bypass
      'X-Bypass-Rate-Limit': BYPASS_KEY,       // Express-rate-limit bypass
    },
  };

  // Journey 1: Health check
  const resHealth = http.get(`${BASE_URL}/health`, params);
  check(resHealth, {
    'health check status is 200': (r) => r.status === 200,
  });
  sleep(1);

  // Journey 2: Attendee registration / check-in (POST payload)
  const checkinPayload = JSON.stringify({
    eventId: '3d8a960e-297c-4b2f-ab43-01da528d5737',
    attendeeName: `Test Attendee ${__VU}_${__ITER}`,
    checkedInAt: new Date().toISOString(),
    verificationLocation: { latitude: 37.7749, longitude: -122.4194 }
  });

  const resCheckin = http.post(`${BASE_URL}/attendance/check-in`, checkinPayload, params);
  check(resCheckin, {
    'check-in status is 201': (r) => r.status === 201 || r.status === 200,
  });
  sleep(2);
}
```

---

## 3. Security Testing Strategy

To safeguard Eventclick's sensitive user verification and attendance data, security checks are divided into automated pipeline gates and manual review processes.

### 3.1 Tool Selection Matrix

| Category | Recommended Tool | Purpose | Frequency |
|---|---|---|---|
| **Secrets Detection** | **GitLeaks** / GitGuardian | Prevent API keys, JWT secrets, and AWS/R2 credentials from entering Git repositories. | Pre-commit & CI/CD |
| **SAST (Static Analysis)** | **Semgrep** & ESLint Security | Scan source code for SQL injections, XSS, insecure cookies, and missing RBAC authorization checks. | Every Pull Request |
| **SCA (Dependency Check)** | **Snyk** or `npm audit` / `trivy` | Detect known CVEs in third-party npm packages (e.g. Express, jsonwebtoken). | Daily Cron / PR Build |
| **Container Security** | **Trivy** | Verify Docker base images used in EC2 deployments are free from OS-level vulnerabilities. | Image build phase |
| **DAST (Dynamic Scanning)** | **OWASP ZAP** (Daemon mode) | Actively scan the running staging application for runtime configuration flaws, CSRF, and session weaknesses. | Weekly / Post-Merge Staging |
| **Manual Pentesting** | **Burp Suite Professional** | Intercept traffic and perform manual audits of multi-tenant organization boundary isolation and IDOR vulnerabilities. | Pre-release / Bi-annually |

### 3.2 Security Lifecycle Integration

```
Dev (Gitleaks, ESLint) ──> Commit (PR) ──> Build (Semgrep, Trivy) ──> Staging (OWASP ZAP) ──> Pre-Release (Burp/Manual) ──> Production
```

#### Phase 1: Local Development & Pre-Commit
- **Gitleaks**: Runs locally before a developer can commit code. Blocks commits containing clear-text secrets (e.g., matching AWS access key regex or `JWT_SECRET`).
- **ESLint Security Plugin**: Runs in IDE. Highlights risky patterns (like `eval()` or unsanitized DOM manipulation causing XSS) on the client/server source files.

#### Phase 2: Pull Request & CI Build
- **Semgrep Security Scan**: Configured with rulesets for JavaScript, TypeScript, and SQL (CWE-89 SQL Injection, CWE-79 XSS, and custom rules for Eventclick).
- **npm audit / Snyk**: Run during build. Fails the build if any dependency has a critical-severity vulnerability with a known patch.
- **Trivy Container Scan**: Scans production Dockerfiles and base images before pushing to container registries.

#### Phase 3: Post-Deployment Staging (DAST)
- **OWASP ZAP Automation**: After code merges to the `main` branch and is deployed to Staging, a GitHub Action initiates an automated OWASP ZAP baseline scan.
- ZAP spider crawls public-facing pages, and active scanners execute standard attack vectors (payload injections, path traversals).
- Runs under a designated "test volunteer" active session using authentication headers passed via script.

#### Phase 4: Release Gate / Manual Audit
- **Burp Suite Pro manual audit**: A security specialist uses Burp to map tenant organizations and event rooms, manually attempting to inject and request resources belonging to other organizations (`Organization B` resources requested using `Organization A` active session cookies). This verifies the multi-tenancy logical isolation rule:
  ```typescript
  // Assert: orgId must match the target resource organizationId
  eq(eventRooms.organizationId, orgId)
  ```

---

## 4. CI/CD Integration Blueprint

Below are GitHub Actions workflow blueprints demonstrating how to orchestrate performance tests and security scanners in the deployment pipeline.

### 4.1 Security Scan Workflow (SAST & Dependencies)

Save as `.github/workflows/security.yml`:

```yaml
name: Security Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]
  schedule:
    - cron: '0 0 * * *' # Daily at midnight

jobs:
  sast-and-dependencies:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Needed for Gitleaks git history scan

      # 1. Check for committed secrets
      - name: Run Gitleaks
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      # 2. Setup Node environment
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-node: '20'
          cache: 'npm'

      # 3. Check for vulnerable dependencies
      - name: Dependency Vulnerability Scan (SCA)
        run: npm audit --audit-level=high

      # 4. Static Code Analysis (SAST)
      - name: Run Semgrep Security Scan
        uses: returntocorp/semgrep-action@v1
        with:
          config: >-
            p/security-audit
            p/owasp-top-ten
            p/typescript
```

### 4.2 Automated Performance Gate (k6 Smoke Test)

Save as `.github/workflows/performance.yml`:

```yaml
name: Performance Verification

on:
  deployment_status: # Run after staging deployment completes successfully

jobs:
  performance-gate:
    if: github.event.deployment_status.state == 'success' && github.event.deployment_status.environment == 'staging'
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Run k6 Load Test (Smoke Profile)
        uses: grafana/k6-action@v0.3.1
        with:
          filename: packages/shared/docs/testing/load-test.js
          flags: --vus 5 --duration 30s
        env:
          TARGET_URL: ${{ github.event.deployment_status.target_url }}/api/v1
          BYPASS_KEY: ${{ secrets.LOAD_TEST_BYPASS_KEY }}
```

---

## 5. Vulnerability Management & SLAs

For any security vulnerabilities or performance degradations identified, we recommend establishing strict response SLAs:

| Severity | Definition | Resolution SLA | Action Required |
|---|---|---|---|
| **Critical** | Remote Code Execution, Auth Bypass, SQL Injection, Data Leak. | **24 Hours** | Immediate hotfix. Rollback deployment if patch cannot be deployed instantly. |
| **High** | Privilege Escalation, Rate limit bypass on authentication, XSS. | **5 Days** | Schedule patch in current sprint cycle. |
| **Medium** | Informational leaks, missing security headers, dependency CVE. | **30 Days** | Resolve in the next development cycle. |
| **Low** | Minor dependency warning, non-sensitive configuration changes. | **90 Days** | Update in normal maintenance schedule. |

This strategy ensures that security and performance are not treated as post-facto checklists, but as automated, testable constraints that safeguard Eventclick's users and donors from Day One.
