# Context

## Objective
The goal is to draft a comprehensive E2E testing strategy document for the Eventclick application, which is deployed on AWS and Cloudflare. The strategy must cover:
- UI testing (e.g., Playwright)
- API testing
- Performance testing
- Security testing (suggesting tools like OWASP ZAP, Burp Suite)
- Test data management strategy in staging and production without polluting real data.
- CI/CD integration plan.
- Responsibility matrix mapping testing phases/types to roles.
- At least 5 critical user journeys with setup steps, expected outcomes, and edge cases.

## Target Location
`packages/shared/docs/testing/e2e-testing-strategy.md`

## Current Iteration
- Direct loop: Phase 1 (Investigation) -> Phase 2 (Drafting) -> Phase 3 (Reviewing) -> Phase 4 (Final Verdict)
