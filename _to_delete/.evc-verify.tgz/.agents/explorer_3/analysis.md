# E2E Testing Strategy: Data, CI/CD, and Critical Journeys

## Executive Summary
This analysis presents the E2E testing framework for the Eventclick platform. It defines: (1) a multi-tenant test data isolation strategy for Postgres, Redis, and Cloudflare R2; (2) a multi-stage CI/CD pipeline integrated via GitHub Actions to automate unit, integration, E2E (Playwright), security (SAST/DAST), and performance (k6) tests; and (3) a detailed execution blueprint for 5 critical business journeys.

---

## 1. Codebase Walkthrough & Key Business Flows

Eventclick is structured as a multi-tenant workspace platform. Here is the call chain and structural walkthrough of the four primary business operations:

### A. Event (Room) Creation
- **Endpoint**: `POST /api/v1/rooms` (mapped via `routes/room.routes.ts` to `createRoom` in `controllers/room.controller.ts`).
- **Database Schema**: Enforces relations on `eventRooms` (located in `packages/server/src/db/schema/eventRooms.ts`).
- **Flow**:
  1. The client sends a payload matching the `CreateRoomSchema` (defined in `packages/shared/src/index.ts`).
  2. The middleware `requireAuth` validates the JWT token and extracts user details (`req.user`).
  3. The controller fetches the user's `organizationId`. If missing, it throws a `400 Bad Request` via `requireOrgId()`.
  4. The controller creates a room in the `eventRooms` table using Drizzle ORM, generating a random 32-character `shareToken` via `nanoid(32)` to allow unauthenticated attendees to check in.
  5. If the creator is not an `ngo_admin` (e.g. they are an `event_admin`), a row is inserted in `eventAdminAssignments` to map them explicitly to the room.

### B. Attendee Registration (Attendance Submission)
- **Endpoint**: `POST /api/v1/rooms/:id/attendance` (mapped to `postAttendance` in `controllers/attendance.controller.ts`).
- **Database Schema**: Writes to `attendanceEntries` (located in `packages/server/src/db/schema/attendanceEntries.ts`).
- **Flow**:
  1. A guest, volunteer, or event admin submits form fields matching `SubmitAttendanceSchema`.
  2. The controller invokes `submitAttendance()` from `services/attendance.service.ts`.
  3. The service calls `isWithinAttendanceWindow()` to verify that the current timestamp is within the active verification window (`scheduledStart - windowBefore` to `actualEnd / scheduledEnd + windowAfter`). If outside, it throws a `400 Bad Request`.
  4. The service fetches the latest form definition from `formDefinitions` table, parses the input fields, and validates them against the schema rules of each field (type checks like `email`, `phone`, `select`, etc.) using a dynamic Zod validator in `validateAndCoerceData()`.
  5. If valid, the submission is recorded in the `attendanceEntries` table, linking the `roomId` and `formDefinitionId`. If a photo proof is attached, the presigned photo key is persisted.

### C. NGO Fieldwork Activity Verification
- **Endpoint**: `POST /api/v1/rooms/:id/activity-submissions` (mapped to `postActivityPhotoSubmission` in `controllers/activity.controller.ts`).
- **Database Schema**: Relies on `activitySubmissions` and `activityPhotos` tables.
- **Flow**:
  1. NGO volunteers capture live fieldwork evidence and submit a specific `activityId` and `photoKey` via the `SubmitActivityPhotoSchema`.
  2. The service verifies the user has access to the event room via `assertRoomAccessWithRoom()`.
  3. It performs a lookup on `eventRooms` to verify the specified `activityId` is defined under `room.activityDefinitions`.
  4. An upsert is executed on `activitySubmissions` for the `(roomId, activityId)` combination. The unique index `activity_submissions_room_activity_uniq` prevents concurrent race conditions from creating duplicate submissions.
  5. The service runs a transaction where it locks `activityPhotos` for that submission, verifies that the count is less than 50, inserts the new photo details (including the generated public URL), and returns the submission with all current photo assets.

### D. Photo Upload (Presigned Put URL)
- **Endpoints**: `POST /api/v1/rooms/:id/attendance/presign` and `POST /api/v1/rooms/:id/activity-submissions/presign`.
- **Flow**:
  1. Before uploading, the client requests a presigned URL by submitting details matching `PhotoUploadRequestSchema` (mimetype, size limit 5MB).
  2. The server asserts that the user belongs to the organization that owns the event room.
  3. It calls `createPresignedPut()` in `services/storage.service.ts`.
  4. The service creates a `PutObjectCommand` targeting the Cloudflare R2 bucket with the file key, content-type, and a `Cache-Control` header.
  5. The AWS S3 SDK's default checksum middleware is stripped out using a low-priority middleware hook (`forceRemoveChecksums`) to prevent Cloudflare R2 from rejecting the signed URL because of header mismatches.
  6. The server generates the presigned URL via `getSignedUrl` and returns it to the client. The client performs a `PUT` request with the raw image buffer directly to Cloudflare R2.

---

## 2. Test Data Management Strategy

To run end-to-end and integration tests in Staging and Production without polluting real NGO data, a strict isolation architecture is proposed.

```
                  ┌──────────────────────────────────────────┐
                  │          ENVIRONMENT ISOLATION           │
                  └──────────────────────────────────────────┘
                                       │
         ┌─────────────────────────────┼─────────────────────────────┐
         ▼                             ▼                             ▼
┌─────────────────┐           ┌─────────────────┐           ┌─────────────────┐
│ POSTGRESQL (DB) │           │  REDIS (CACHE)  │           │  R2 (STORAGE)   │
└─────────────────┘           └─────────────────┘           └─────────────────┘
 Staging:                      Staging:                      Staging:
 ├─ Ephemeral Test DB          ├─ DB Index 1                 ├─ Dedicated Bucket
 ├─ Migrated/Cleared in CI     ├─ Prefix: 'test:*'           ├─ (eventclick-test)
 │                             │                             │
 Production:                   Production:                   Production:
 ├─ Dedicated QA Tenant        ├─ DB Index 0                 ├─ Root Bucket
 ├─ (UUID: ffff-ffff...)       ├─ Prefix: 'prod:*'           ├─ Prefix: 'test/*'
 └─ Soft-Delete Sweeper        └─ Queue Prefixes             └─ R2 Lifecycle TTL (24h)
```

### A. Database (Postgres) Strategy

| Feature | Staging / CI Environment | Production Environment |
|---|---|---|
| **Database Instance** | **Physical Isolation**: Run on a dedicated ephemeral test database `eventclick_staging_test` (local container or separate AWS RDS database schema). | **Shared Database**: Tests run on the live production database. Physical database replication is not possible. |
| **Tenant Partitioning** | **N/A**: Tests can use mock data or dynamic organizations. | **The Test Tenant Pattern**: Register a permanent, immutable QA organization ("Eventclick QA Tenant") with a fixed UUID: `ffffffff-ffff-ffff-ffff-ffffffffffff`. |
| **Security Controls** | **Global Access**: Test suite holds superuser credentials to spin up/truncate schemas. | **Strict RBAC Enforcement**: Test users belong only to the QA tenant. Since the codebase forces multi-tenancy partitions (`eq(eventRooms.organizationId, orgId)`), test users are logically blocked from ever querying or modifying real NGO data. |
| **Teardown & Cleanup** | **Schema Truncation**: Run `TRUNCATE TABLE ... CASCADE` on all tables in a global test teardown hook. | **Soft-Delete Daemon**: A scheduled script (BullMQ or ECS task cron) runs every 24 hours to find all rooms/attendance under the QA tenant UUID and hard-deletes them. |

### B. Cache & Queue (Redis) Strategy
1. **Database Index Isolation**:
   - In Staging/CI, configure `REDIS_URL` to point to a separate Redis DB index (e.g. `redis://redis:6379/1`).
   - In Production, keep the default DB `0` (e.g. `redis://redis:6379/0`). This prevents test keys from colliding with live user sessions.
2. **Key Namespacing**:
   - Modify the cache utility to prepend a namespace: `test:cache:` in tests, and `prod:cache:` in production.
   - For BullMQ queues, use a queue prefix configuration (e.g., `eventclick-test-queue`).
3. **Flushing**:
   - In CI/Staging, tests run `redisClient.flushDb()` during teardown.
   - In Production, tests do not flush Redis. All keys created by tests are set with a strict TTL (maximum 1 hour).

### C. Object Storage (Cloudflare R2) Strategy
1. **Staging/CI Isolation**:
   - Configure the environment variable `S3_BUCKET` to a dedicated bucket `eventclick-staging-assets`. Never configure staging to point to the production bucket.
2. **Production Canary Logical Isolation**:
   - When running smoke tests in production, prefix all uploaded keys with `test/` (e.g., `test/attendance/...`, `test/rooms/...`).
   - Update `buildPhotoKey` and `buildActivityPhotoKey` to check if `NODE_ENV === 'test'` or if the event room belongs to the QA tenant, prepending `test/` dynamically.
3. **Cloudflare R2 Lifecycle Policy**:
   - Configure a native **R2 Lifecycle Rule** on the production bucket:
     ```json
     {
       "Rules": [{
         "ID": "DeleteProductionTestUploads",
         "Status": "Enabled",
         "Filter": { "Prefix": "test/" },
         "Expiration": { "Days": 1 }
       }]
     }
     ```
   - This automatically garbage-collects test uploads after 24 hours, preventing storage cost bloat.

---

## 3. CI/CD Integration Plan (GitHub Actions)

A two-stage workflow is proposed: **Continuous Integration (CI)** running on PRs and merges to `main`, and **Continuous Deployment (CD)** deploying to environments and orchestrating tests.

```
[ Developer Push ]
       │
       ▼
┌──────────────┐
│  CI Workflow │ (lint, typecheck, unit tests, fast integration tests, Trivy)
└──────┬───────┘
       │ (Passes on 'main')
       ▼
┌──────────────┐
│  CD Workflow │ (Builds Docker images → GHCR)
└──────┬───────┘
       │
       ▼
┌──────────────────┐
│ Deploy to Staging│
└──────┬───────────┘
       │
       ▼
┌─────────────────────────────────┐
│ Post-Deployment Staging Tests  │
│ ├─ Playwright E2E Test Suite    │ (Spins up mock LiveKit, runs 5 Journeys)
│ ├─ k6 Performance Tests         │ (Asserts P95 < 200ms)
│ └─ OWASP ZAP API Scan           │ (DAST vulnerability scan)
└──────┬──────────────────────────┘
       │ (All green)
       ▼
 ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
 ▒  Manual Gate   ▒ (Requires Senior Release Manager Approval)
 ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
       │
       ▼
┌───────────────────┐
│ Deploy to Prod    │
└──────┬────────────┘
       │
       ▼
┌───────────────────┐
│ Production Smoke  │ (Runs safe non-destructive tests inside QA Tenant)
└───────────────────┘
```

### A. CI Workflow (`.github/workflows/ci.yml` - Key Enhancements)
The existing `ci.yml` is expanded to include dependency security scans:
- **Trivy Vulnerability Scan**: Scans packages for CVEs.
- **Node Security Audit**: Enforces `npm audit --audit-level=high`.

### B. Playwright Test Integration (E2E)
To run Playwright tests in Staging or CI, the pipeline spins up the entire application stack:
1. **Containerized Setup**: Uses `docker-compose.test.yml` to launch Postgres, Redis, Gotenberg (PDF generator), and a Mock LiveKit Server.
2. **Database Seeding**: Runs migration and seeds the database with the core test tenant structure.
3. **Execution**: Playwright tests run headlessly in parallel. On failure, trace zip files and screenshots are uploaded as run artifacts.

```yaml
# Add to CI or Post-Deploy Staging
playwright-e2e:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-node@v4
      with:
        node-version: "20"
        cache: "npm"
    - name: Start Services
      run: docker compose -f docker-compose.test.yml up -d
    - name: Install Playwright Browsers
      run: npx playwright install --with-deps
    - name: Run E2E Tests
      run: npm run test:e2e
      env:
        DATABASE_URL: postgres://postgres:postgres@localhost:5432/eventclick_test
        REDIS_URL: redis://localhost:6379/1
    - name: Upload Test Artifacts
      if: failure()
      uses: actions/upload-artifact@v4
      with:
        name: playwright-report
        path: playwright-report/
        retval: 30
```

### C. Security Testing Integration
1. **SAST (Static Application Security Testing)**:
   - Run **Semgrep** during CI to detect SQL injection (Drizzle raw queries), hardcoded secrets, or insecure random generators (using `nanoid` vs `crypto`).
2. **DAST (Dynamic Application Security Testing)**:
   - Post-deployment to staging, run **OWASP ZAP** in daemon mode targeting the Staging API base (`https://staging-api.eventclick.org`).
   - Run a focused scan on unauthenticated endpoints (e.g. `/api/v1/rooms/share/:token`) to check for SQL injection, path traversal, or information disclosure.

### D. Performance Verification
- Run **k6 load tests** post-staging deploy.
- Assertions block deployment if:
  - Latency check: `http_req_duration{status:200} p(95) < 200ms` (excluding LiveKit WebRTC).
  - Error rate: `http_req_failed < 0.01` (less than 1% failure under 100 concurrent virtual users).

---

## 4. Detailed Outlines of Critical User Journeys

Here are the detailed outlines for 5 critical user journeys covering setup steps, execution sequences, verification points, and edge cases.

### Journey 1: NGO Registration & Onboarding
**Goal**: Verify a new NGO can create an account, verify their email, and complete organization onboarding.

*   **Setup Steps**:
    1. Clean the database or verify that the email `test-ngo-admin@eventclick.org` does not exist.
    2. Mock the outbound email queue/SQS worker to capture sent email payloads.
*   **Execution Sequence**:
    1. Client triggers `POST /api/v1/auth/register` with:
       ```json
       {
         "email": "test-ngo-admin@eventclick.org",
         "password": "SecurePassword123!",
         "fullName": "Test Admin"
       }
       ```
    2. Server returns `201 Created` with user details (inactive/unverified status).
    3. Test reads the mock SQS queue or the `email_verifications` table to retrieve the generated verification token.
    4. Client triggers `POST /api/v1/auth/verify-email` sending the token.
    5. Server returns `200 OK` with user details, an access token, and a secure HTTP-Only refresh token.
    6. Client triggers onboarding via `POST /api/v1/auth/onboard` with:
       ```json
       {
         "organizationName": "Greenwood Relief NGO",
         "role": "ngo_admin"
       }
       ```
*   **Expected Outcomes**:
    1. A new user and organization are created in `users` and `organizations` tables.
    2. An entry in `orgMembers` registers the user as `ngo_admin` for that organization.
    3. User profile indicates `emailVerified: true` and `organizationId` is successfully linked.
*   **Edge Cases & Error Scenarios**:
    1. **Duplicate Email**: Trying to register with an existing email returns `400 Bad Request` or `409 Conflict`.
    2. **Invalid Password Strength**: Password without numbers/special chars is caught by the Zod `PasswordSchema` validator, returning `400 Bad Request`.
    3. **Expired Token**: Using a verification token after 24 hours returns `400 Bad Request` (expired).

---

### Journey 2: Event Room Scheduling & Configuration
**Goal**: Verify an NGO Admin can schedule a fieldwork event room, build a custom attendance form, and define activity proof quotas.

*   **Setup Steps**:
    1. User is logged in as `ngo_admin`.
*   **Execution Sequence**:
    1. Client triggers `POST /api/v1/rooms` with event configuration:
       ```json
       {
         "title": "Flood Relief Supplies Distribution",
         "scheduledStart": "2026-07-17T09:00:00Z",
         "scheduledEnd": "2026-07-17T12:00:00Z",
         "attendanceWindowBefore": 15,
         "attendanceWindowAfter": 30,
         "activityDefinitions": [
           { "id": "supplies_photo", "title": "Supplies Log Photo", "min_photos": 1 },
           { "id": "distribution_photo", "title": "Recipient Handover Photo", "min_photos": 2 }
         ]
       }
       ```
    2. Server returns `201 Created` and provides the created room details, including the generated `shareToken`.
    3. Client queries the room ID to configure a custom attendance form, triggering `POST /api/v1/rooms/:id/form` with:
       ```json
       {
         "fields": [
           { "id": "beneficiary_name", "label": "Full Name", "type": "text", "required": true },
           { "id": "gov_id", "label": "National ID Number", "type": "text", "required": false },
           { "id": "supplies_category", "label": "Supplies Received", "type": "select", "required": true, "options": ["Food Kit", "Hygiene Kit", "Shelter Tarps"] }
         ]
       }
       ```
    4. Server returns `200 OK` confirming the form structure has been saved.
*   **Expected Outcomes**:
    1. The room is registered in `eventRooms` with `status: 'scheduled'`.
    2. A `formDefinitions` row is written with `version: 1` linked to the `roomId`.
    3. The generated `shareUrl` is formatted correctly (`https://[app_url]/watch/[shareToken]`).
*   **Edge Cases & Error Scenarios**:
    1. **Time Collision**: Setting `scheduledEnd` prior to `scheduledStart` causes a Zod schema validation error.
    2. **Missing Select Options**: Saving a "select" field type in the form builder without providing any strings in the `options` array returns a `400 Bad Request` (caught by the form-field schema `superRefine` check).
    3. **Permission Bypass**: A user with the role `volunteer` attempting to update the form definition receives `403 Forbidden` (RBAC restriction).

---

### Journey 3: Attendee Check-In (Dynamic Form & Photo Proof)
**Goal**: Verify a remote participant or local beneficiary can check in to a live event by completing the dynamic form and uploading a selfie.

*   **Setup Steps**:
    1. An event room is created and its status is set to `live`.
    2. A form definition is created for the room.
    3. The user has the public `shareToken` for the room.
*   **Execution Sequence**:
    1. Client triggers `GET /api/v1/rooms/share/:token` to fetch public room parameters.
    2. Client requests a photo upload presigned URL via `POST /api/v1/rooms/:roomId/attendance/presign` sending the mimetype and size.
    3. Server checks organizational access and returns a presigned PUT URL pointing to the Cloudflare R2 bucket.
    4. Client uploads the JPEG image byte stream directly to the R2 URL.
    5. Client submits the attendance form data to `POST /api/v1/rooms/:roomId/attendance` with:
       ```json
       {
         "formDefinitionId": "uuid-form-definition",
         "data": {
           "beneficiary_name": "Jane Doe",
           "gov_id": "123-456-789",
           "supplies_category": "Food Kit"
         },
         "photoKey": "attendance/room-id/photo-nanoid.jpg"
       }
       ```
*   **Expected Outcomes**:
    1. Attendance submission returns `201 Created`.
    2. A row is inserted in `attendanceEntries` with the provided field data and the resolved `photoUrl` mapping to R2.
    3. The room's presence registry reflects the participant's check-in status.
*   **Edge Cases & Error Scenarios**:
    1. **Submit Outside Window**: Submitting attendance when the event is still "scheduled" (and prior to the `windowBefore` duration) throws a `400 Bad Request` with "Attendance can only be submitted during the active window".
    2. **Missing Required Fields**: Submitting the form payload without the required `beneficiary_name` field throws `400 Bad Request` with validation error messages.
    3. **R2 Upload Failure**: If the client submits the form with a `photoKey` before performing the PUT upload to R2, the entry is registered in Postgres, but any subsequent download of the verification report will handle the broken photo reference gracefully (no server-side crashes).

---

### Journey 4: Volunteer Fieldwork Activity Proof Upload
**Goal**: Verify field volunteers can submit photo proof for specific activities, enforcing safety limits and validation.

*   **Setup Steps**:
    1. A room is created with activity definitions, and set to `live`.
    2. A user with the `volunteer` role is logged in and assigned to the room in `eventAdminAssignments`.
*   **Execution Sequence**:
    1. Client requests an activity upload URL via `POST /api/v1/rooms/:id/activity-submissions/presign` specifying `activityId: 'supplies_photo'`, mimetype, and size.
    2. Server verifies room access, checks that the `activityId` is defined, and returns the presigned URL.
    3. Client uploads the image byte stream to the R2 bucket.
    4. Client registers the upload via `POST /api/v1/rooms/:id/activity-submissions` sending:
       ```json
       {
         "activityId": "supplies_photo",
         "photoKey": "rooms/room-id/activities/supplies_photo_timestamp.jpg"
       }
       ```
    5. Server runs a database transaction, verifies the photo limit, and logs the upload.
*   **Expected Outcomes**:
    1. A row is created or updated in `activitySubmissions`.
    2. A new entry is written in `activityPhotos` referencing the submission ID.
    3. Returns `201 Created` with a list of all uploaded photo URLs for that activity.
*   **Edge Cases & Error Scenarios**:
    1. **Max Limit Exceeded**: If a volunteer attempts to submit a 51st photo for the same activity, the transaction rollback triggers a `400 Bad Request` ("Maximum of 50 photos allowed per activity").
    2. **Unregistered Activity ID**: Attempting to upload to an activity ID not defined in the room configuration yields `400 Bad Request`.
    3. **Unassigned Volunteer Access**: A volunteer who is not assigned to the specific event room attempts to upload, yielding a `403 Forbidden` response.

---

### Journey 5: Live Session Closure & Fieldwork Verification Audit Report
**Goal**: Verify an NGO Admin can conclude a live event, reconcile attendance counts, and download a secure PDF verification audit report.

*   **Setup Steps**:
    1. An event room is `live`, and multiple attendees have checked in.
    2. Volunteers have uploaded activity submissions.
    3. A user is logged in as `ngo_admin`.
*   **Execution Sequence**:
    1. Client triggers the room closure via `PATCH /api/v1/rooms/:id` sending:
       ```json
       {
         "status": "ended"
       }
       ```
    2. Server marks the room status, closes the LiveKit room, and records `actualEnd` timestamp.
    3. Client requests the verification audit report via `GET /api/v1/rooms/:id/report`.
    4. Server validates access, fetches organization details, checks all attendance records, and queries activity photos.
    5. The server compiles the data into HTML, calls the Gotenberg service via HTTP, generates a PDF, and streams the PDF buffer back to the client.
*   **Expected Outcomes**:
    1. Room status transitions to `ended`.
    2. The generated PDF matches compliance layout: contains NGO name, event title, timestamps, geolocated attendance table, and thumbnail links of all activity photos.
*   **Edge Cases & Error Scenarios**:
    1. **Early Report Download**: Attempting to query `/report` while the event is still `live` throws `400 Bad Request` ("Report can only be generated after the live session has ended").
    2. **Missing Gotenberg Service**: If the Gotenberg container is unresponsive, the server log captures the error, handles it gracefully, and returns `503 Service Unavailable` instead of crashing.
    3. **Zero Attendance Reconciliation**: If a room ends with zero check-ins, the PDF compiles successfully showing a blank attendance table rather than returning an error.
