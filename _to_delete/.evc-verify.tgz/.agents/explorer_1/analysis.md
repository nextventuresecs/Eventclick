# Eventclick E2E UI & API Testing Strategy Recommendation

This document outlines a production-grade testing strategy for Eventclick, addressing the user interface (UI) and application programming interface (API) layers. This strategy targets the Express backend, React frontend, and PostgreSQL database, integrating E2E testing from scratch in a multi-tenant environment.

---

## 1. Codebase Current State & Discovery Findings

During codebase exploration, we identified the following parameters:

*   **Monorepo Structure**: The application uses `npm` workspaces and `turbo` for build orchestration.
    *   `packages/client`: React 19.x + Vite 8.x + Tailwind CSS 4.x + React Router 7.x. Uses a custom fetch wrapper (`api` and `authApi`) inside `src/lib/api.ts` pointing to `/api/v1`. Currently, **zero** tests exist.
    *   `packages/server`: Express 5.x + Drizzle ORM + Node-Postgres + Redis. Uses `vitest` for unit/integration tests located in `src/services/__tests__/`. Configured in `vitest.config.ts`.
    *   `packages/shared`: Shared types, Zod schemas, and authorization helpers (`hasRolePermission`).
*   **Existing Test Setup**:
    *   Vitest is the sole testing framework present. It is scoped to `packages/server` and is configured to override environment variables (e.g., `DATABASE_URL` points to a local test db).
    *   Existing database-related service tests mock the database access chain (using Vitest's `vi.mock` to mock `drizzle` chaining) rather than running against an active database instance.
    *   No end-to-end integration tests (querying HTTP endpoints via a running server) exist.
    *   No UI testing framework (Jest, Vitest, Cypress, or Playwright) is set up in `packages/client`.

---

## 2. Playwright UI Testing Strategy

Playwright is recommended for UI and E2E testing due to its fast execution, auto-waiting, native monorepo support, and robust handling of modern web APIs (like WebRTC and WebSockets).

### A. Monorepo Directory & Config Structure
To prevent pollution of the client runtime workspace, E2E tests should be placed in a dedicated workspace package: `packages/e2e`.

#### Recommended `packages/e2e/package.json`
```json
{
  "name": "e2e",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "test": "playwright test",
    "test:ui": "playwright test --ui",
    "test:debug": "playwright test --debug",
    "codegen": "playwright codegen http://localhost:3000"
  },
  "devDependencies": {
    "@playwright/test": "^1.49.0",
    "typescript": "^6.0.0"
  }
}
```

#### Recommended `packages/e2e/playwright.config.ts`
```typescript
import { defineConfig, devices } from "@playwright/test";
import path from "path";

export default defineConfig({
  testDir: "./tests",
  timeout: 35 * 1000,
  expect: { timeout: 5000 },
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [["html"], ["list"]],
  use: {
    baseURL: process.env.PLAYWRIGHT_TEST_BASE_URL || "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
    ignoreHTTPSErrors: true,
  },
  // Automatically start backend server & Vite dev client before running tests
  webServer: process.env.CI ? [
    {
      command: "npm run dev --workspace=server",
      url: "http://localhost:5001/api/v1/health",
      reuseExistingServer: !process.env.CI,
      timeout: 120 * 1000,
    },
    {
      command: "npm run dev --workspace=client",
      url: "http://localhost:3000",
      reuseExistingServer: !process.env.CI,
      timeout: 120 * 1000,
    }
  ] : undefined,
  projects: [
    {
      name: "chromium",
      use: { 
        ...devices["Desktop Chrome"],
        launchOptions: {
          args: [
            "--use-fake-ui-for-media-stream",
            "--use-fake-device-for-media-stream"
          ]
        }
      },
    },
    {
      name: "firefox",
      use: { ...devices["Desktop Firefox"] },
    },
    {
      name: "webkit",
      use: { ...devices["Desktop Safari"] },
    },
    {
      name: "Mobile Chrome",
      use: { 
        ...devices["Pixel 5"],
        launchOptions: {
          args: [
            "--use-fake-ui-for-media-stream",
            "--use-fake-device-for-media-stream"
          ]
        }
      },
    },
    {
      name: "Mobile Safari",
      use: { ...devices["iPhone 12"] },
    },
  ],
});
```

### B. Shared Authentication State (`storageState`)
Logging in through the UI for every test file degrades suite performance. We will implement global authentication setup.

1.  **Global Setup Script (`playwright/global-setup.ts`)**: Runs once before tests, logs in as distinct roles, and serializes state (cookies & localStorage) to files.
2.  **Role Injection**: In the configuration or individual test files, load the respective role state.

#### Sample `packages/e2e/tests/auth.setup.ts`
```typescript
import { test as setup, expect } from "@playwright/test";
import path from "path";

const authDir = path.join(__dirname, "../.auth");

setup("authenticate as NGO Admin", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Email").fill("admin@testngo.org");
  await page.getByLabel("Password").fill("TestAdmin123!");
  await page.getByRole("button", { name: "Sign In" }).click();

  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  await page.context().storageState({ path: path.join(authDir, "ngo_admin.json") });
});

setup("authenticate as Volunteer", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Email").fill("volunteer@testngo.org");
  await page.getByLabel("Password").fill("TestVolunteer123!");
  await page.getByRole("button", { name: "Sign In" }).click();

  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  await page.context().storageState({ path: path.join(authDir, "volunteer.json") });
});
```

#### Usage in E2E Tests (`packages/e2e/tests/rooms.spec.ts`)
```typescript
import { test, expect } from "@playwright/test";
import path from "path";

test.describe("NGO Admin Event Controls", () => {
  test.use({ storageState: path.join(__dirname, "../.auth/ngo_admin.json") });

  test("can create a new event room", async ({ page }) => {
    await page.goto("/rooms/create");
    await page.getByLabel("Room Name").fill("Verification Session - North District");
    await page.getByLabel("Scheduled Start").fill("2026-07-20T10:00");
    await page.getByRole("button", { name: "Create Room" }).click();

    await expect(page.locator("text=Room created successfully")).toBeVisible();
  });
});
```

### C. Page Object Model (POM) Design
We will structure tests using POM classes placed in `packages/e2e/pages/`.

#### Locator Strategy
*   **Preferred**: User-facing accessibility roles (e.g. `page.getByRole('button', { name: 'Save' })`, `page.getByLabel('Room Name')`). This guarantees tests assert accessibility.
*   **Secondary**: `page.getByTestId('element-name')`. Used for custom UI controls (like form builder drag-and-drop elements).
*   **Strictly Avoid**: Brittle CSS paths (e.g. `div > div > span > button`).

#### Implementation Mockup: Attendance Submission Page Object
```typescript
// packages/e2e/pages/AttendancePage.ts
import { Page, Locator, expect } from "@playwright/test";

export class AttendancePage {
  readonly page: Page;
  readonly nameInput: Locator;
  readonly photoUploadInput: Locator;
  readonly submitButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.nameInput = page.getByLabel("Attendee Full Name");
    this.photoUploadInput = page.locator('input[type="file"]');
    this.submitButton = page.getByRole("button", { name: "Submit Attendance" });
  }

  async goto(roomId: string) {
    await this.page.goto(`/rooms/${roomId}/attendance`);
  }

  async submitRecord(name: string, photoPath?: string) {
    await this.nameInput.fill(name);
    if (photoPath) {
      await this.photoUploadInput.setInputFiles(photoPath);
      // Wait for image compression and validation UI indicator
      await expect(this.page.locator("text=Ready to upload")).toBeVisible();
    }
    await this.submitButton.click();
  }
}
```

### D. Testing Real-time Systems (LiveKit WebRTC & WebSockets)

Eventclick features WebRTC-based streaming (`RoomLive.tsx`, `RoomWatch.tsx`) and WebSocket presence checking.

1.  **WebRTC Media Emulation**:
    *   Chrome is launched with `--use-fake-device-for-media-stream` and `--use-fake-ui-for-media-stream` flags.
    *   This forces browsers to mock input from a camera (supplying a rotating color wheel or synthetic grid) and microphone (sending a constant audio sine wave), bypassing OS hardware prompts.
2.  **LiveKit Sandbox Strategy**:
    *   In local/CI environments, the server connects to a local developer LiveKit server instance or a mock server SDK.
    *   For UI assertion, verify that the `@livekit/components-react` wrappers correctly mount the `<video>` element. Playwright can assert visual rendering by expecting:
        ```typescript
        const videoElement = page.locator("video");
        await expect(videoElement).toBeVisible();
        await expect(videoElement).toHaveJSProperty("readyState", 4); // HAVE_ENOUGH_DATA
        ```
3.  **Presence & WebSocket Verification**:
    *   Verify real-time attendance counts and live participant listings.
    *   Assert that participant icons render when a user joins:
        ```typescript
        const participantBadge = page.getByTestId("presence-user-avatar");
        await expect(participantBadge).toHaveCount(2); // Local admin + simulated volunteer
        ```

---

## 3. API Testing Strategy

Our API strategy guarantees validation checks, security barriers, and business operations are correct without invoking heavy client UI elements.

### A. Endpoint & Routing Tests
We will write API integration tests in `packages/server` using `supertest` running in a Vitest context. These tests run HTTP requests directly against the Express `app` instance.

#### Sample `packages/server/src/routes/__tests__/room.routes.test.ts`
```typescript
import { describe, it, expect, beforeEach } from "vitest";
import request from "supertest";
import { app } from "../../index";
import { signAccessToken } from "../../services/jwt.service";
import { db } from "../../db";
import { sql } from "drizzle-orm";

describe("POST /api/v1/rooms", () => {
  let ngoAdminToken: string;
  let volunteerToken: string;

  beforeEach(async () => {
    // Truncate tables to ensure database isolation
    await db.execute(sql`TRUNCATE TABLE users, organizations, event_rooms CASCADE`);

    // Setup seed data
    const orgId = "org_test_123";
    ngoAdminToken = signAccessToken({ id: "admin_1", role: "ngo_admin", organizationId: orgId });
    volunteerToken = signAccessToken({ id: "volunteer_1", role: "volunteer", organizationId: orgId });
  });

  it("permits NGO Admins to create a room", async () => {
    const response = await request(app)
      .post("/api/v1/rooms")
      .set("Authorization", `Bearer ${ngoAdminToken}`)
      .send({
        name: "North Division Checkpoint",
        scheduledStart: new Date(Date.now() + 86400000).toISOString(),
        scheduledEnd: new Date(Date.now() + 172800000).toISOString(),
      });

    expect(response.status).toBe(201);
    expect(response.body.name).toBe("North Division Checkpoint");
  });

  it("blocks Volunteers from creating a room (RBAC validation)", async () => {
    const response = await request(app)
      .post("/api/v1/rooms")
      .set("Authorization", `Bearer ${volunteerToken}`)
      .send({
        name: "Illegal Room Creation Attempt",
        scheduledStart: new Date().toISOString(),
        scheduledEnd: new Date().toISOString(),
      });

    expect(response.status).toBe(403);
    expect(response.body.error).toBe("FORBIDDEN");
  });
});
```

### B. Database Isolation & Reset Hooks
To prevent database cross-pollution between tests:
1.  **Drizzle Truncation Utility**: Since Express requests are processed out-of-process relative to the test runner context, Drizzle transaction rollbacks inside a test block do not prevent database mutations caused by HTTP endpoints.
2.  We will run a global `beforeEach` hook that executes raw SQL truncation on all tables:
    ```typescript
    // packages/server/src/test-utils/db-cleaner.ts
    import { db } from "../db";
    import { sql } from "drizzle-orm";

    export async function truncateAllTables() {
      const tables = [
        "users",
        "organizations",
        "org_members",
        "event_rooms",
        "form_definitions",
        "attendance_entries",
        "activity_submissions",
        "activity_photos",
        "room_recordings"
      ];
      await db.execute(sql.raw(`TRUNCATE TABLE ${tables.join(", ")} RESTART IDENTITY CASCADE`));
    }
    ```

### C. Zod Contract Validation
Use Zod schemas defined in `@application/shared` to enforce input and output contract compliance on endpoints. This prevents drift between the server implementation and the client application.

```typescript
import { CreateRoomSchema, EventRoomSchema } from "@application/shared";

// Validate request payload in routes
const parsedPayload = CreateRoomSchema.safeParse(req.body);
if (!parsedPayload.success) {
  throw ApiError.badRequest("Invalid input schemas");
}

// Validate response payload in tests
const validationResult = EventRoomSchema.safeParse(response.body);
expect(validationResult.success).toBe(true);
```

### D. Mocking Strategies for External Dependencies

To run E2E API tests fast and deterministically in CI, we mock third-party networks:

| External Service | Mocking Method | Local Replacement / Assertion |
| :--- | :--- | :--- |
| **AWS S3** | Mock `@aws-sdk/client-s3` client methods or run local **MinIO** container | Confirm upload keys, verify presigned S3 URL formats are generated correctly. |
| **LiveKit Server API** | Mock the `RoomServiceClient` and token generator methods | Return static mock connection tokens containing correct token claims. |
| **Resend (Email)** | Mock API client class to capture outgoing payloads | Inspect `sentEmail` buffers in memory to assert recovery/invitation link contents. |
| **Redis** | Mock Redis client or run local Redis instance | Disable rate limit middleware in testing environments or mock rate limit store. |

---

## 4. Test Data Management Strategy

A vital aspect of testing production-like environments (AWS/Cloudflare) without polluting operational NGO logs is strict tenant isolation.

1.  **Organizational Namespace Separation**:
    *   All test seeds run under organization records prefixed with `TEST_ORG_`.
    *   Tests targeting multi-tenancy validation must explicitly assert that data from `TEST_ORG_A` cannot be queried using an authorization context matching `TEST_ORG_B`.
2.  **Staging Data Purging**:
    *   Provide a secure cleanup script executing at the termination of staging pipelines:
        ```sql
        -- Purge test organization data
        DELETE FROM organizations WHERE id LIKE 'TEST_ORG_%';
        ```
3.  **No Mock Data in Production**:
    *   Production endpoints block requests where user metadata matching `organizationId` begins with `TEST_ORG_`.

---

## 5. Responsibility Matrix

To maintain long-term test suite health, responsibilities are mapped across development roles:

| Testing Level | Primary Writer | Primary Runner | Execution Stage | Maintenance Owner |
| :--- | :--- | :--- | :--- | :--- |
| **Unit Tests (Vitest)** | Feature Developer | Developer | Local Commit, PR Pipeline | Feature Developer |
| **API Endpoint Integration** | Backend Developer | Developer / CI | Pre-merge, PR Pipeline | Backend Team |
| **UI Integration (Playwright)** | Frontend Developer | Developer / CI | PR Pipeline, Nightly | Frontend Team |
| **E2E Critical Journeys** | QA / Lead Developer | CI Pipeline | Post-deploy Staging, Nightly | QA / Lead Developer |
| **Security Scanning (SAST/DAST)** | Security Engineer | Automated CI | Staging deployment gates | Security Team |

---

## 6. CI/CD Integration Plan

E2E testing is automated inside the CI/CD pipeline (e.g. GitHub Actions) to run on every Pull Request and main branch merge.

```yaml
name: CI Test Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest

    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: Eventclick_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

      redis:
        image: redis:7
        ports:
          - 6379:6379

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-size: 20
          cache: 'npm'

      - name: Install Monorepo Dependencies
        run: npm ci

      - name: Setup Test Environment Variables
        run: |
          cp packages/server/.env.example packages/server/.env.test
          # Set database and redis URLs targeting service containers

      - name: Run Database Migrations (Test DB)
        run: npm run db:migrate --workspace=server
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/Eventclick_test

      - name: Run Backend Vitest Unit/Integration Suite
        run: npm run test --workspace=server

      - name: Install Playwright Browsers and System Dependencies
        run: npx playwright install --with-deps

      - name: Run Playwright E2E UI Suite
        run: npm run test --workspace=e2e
        env:
          PLAYWRIGHT_TEST_BASE_URL: http://localhost:3000
          DATABASE_URL: postgresql://test:test@localhost:5432/Eventclick_test
          REDIS_URL: redis://localhost:6379/1

      - name: Upload Playwright Reports on Failure
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: packages/e2e/playwright-report/
          retention-days: 14
```
